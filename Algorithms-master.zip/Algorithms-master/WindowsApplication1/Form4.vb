﻿Public Class Form4
    Dim _generator As Random = New Random()
    Dim _arr(5, 5) As Integer

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub
End Class